a = 4
b = 9
print('a is {} b is {}'.format(a,b))