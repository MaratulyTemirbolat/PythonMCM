myList = []

number = int(input('Type, the number: '))

while number!=0:
	myList.append(number)
	number = int(input('Type,the number: '))
print(myList)
