def do_math_oper():
	x = 7 + 3 * 6/2-1
	print('7 + 3 * 6/2-1 = ' + str(x))
	x = (3 * 9 * (3 + (4*5/3)))
	print('(3 * 9 * (3 + (4*5/3))) = ' + str(x))
	x = 12.0 + 2/5 * 10.0
	print('12.0 + 2/5 * 10.0 = ' + str(x))
	x = 2/5 + 10.0*3 - 2.5
	print('2/5 + 10.0*3 - 2.5 = '+ str(x))
def main():
	do_math_oper()
main()