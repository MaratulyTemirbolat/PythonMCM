number_list = [1, 5 ,3 ,8 ,9]
print(sorted(number_list))
number_list.append(19)
print(number_list)

j = ['1','2','4']
j += ['5asdas']

print(j)

print(len(j))

print(sum(number_list))

print(number_list[-5])